import json
from pathlib import Path

import pandas as pd
import pytest

from etl.quality import DataQualityError, run_checks
from etl.transform import COLUMNS, combine, to_dataframe

FIXTURE = Path(__file__).parent / "fixtures" / "sample_response.json"


@pytest.fixture
def raw():
    return json.loads(FIXTURE.read_text())


@pytest.fixture
def df(raw):
    return to_dataframe(raw, "Chennai")


def test_transform_shape_and_columns(df):
    assert list(df.columns) == COLUMNS
    assert len(df) == 4
    assert (df["city"] == "Chennai").all()


def test_transform_derives_average(df):
    assert df.loc[0, "temp_avg_c"] == pytest.approx((33.4 + 25.2) / 2, abs=0.01)


def test_transform_drops_duplicate_days(raw):
    raw["daily"]["time"].append("2025-10-04")
    raw["daily"]["temperature_2m_max"].append(34.5)
    raw["daily"]["temperature_2m_min"].append(26.0)
    raw["daily"]["precipitation_sum"].append(0.0)
    out = to_dataframe(raw, "Chennai")
    assert len(out) == 4
    assert out.iloc[-1]["temp_max_c"] == 34.5  # keeps the latest value


def test_transform_rejects_missing_daily_block():
    with pytest.raises(ValueError):
        to_dataframe({"latitude": 1}, "Chennai")


def test_combine_stacks_frames(raw):
    out = combine([to_dataframe(raw, "Chennai"), to_dataframe(raw, "Mumbai")])
    assert len(out) == 8
    assert set(out["city"]) == {"Chennai", "Mumbai"}


def test_quality_passes_on_good_data(df):
    results = run_checks(df, expected_cities=1)
    assert all(results.values())


def test_quality_fails_on_duplicates(df):
    bad = pd.concat([df, df.iloc[[0]]], ignore_index=True)
    with pytest.raises(DataQualityError, match="no_duplicate_keys"):
        run_checks(bad)


def test_quality_fails_on_implausible_temperature(df):
    df.loc[0, "temp_max_c"] = 120.0
    with pytest.raises(DataQualityError, match="temp_in_plausible_range"):
        run_checks(df)


def test_quality_fails_when_max_below_min(df):
    df.loc[1, "temp_max_c"] = 10.0
    with pytest.raises(DataQualityError, match="max_gte_min"):
        run_checks(df)


def test_quality_fails_on_negative_rain(df):
    df.loc[2, "precipitation_mm"] = -1.0
    with pytest.raises(DataQualityError, match="precip_non_negative"):
        run_checks(df)


def test_quality_fails_on_missing_city(df):
    with pytest.raises(DataQualityError, match="all_cities_present"):
        run_checks(df, expected_cities=4)


def test_quality_fails_on_empty_frame(df):
    with pytest.raises(DataQualityError, match="not_empty"):
        run_checks(df.iloc[0:0])
